﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;

namespace Banco00
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection conexao;

            conexao = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=banco00;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            conexao.Open();
            Console.WriteLine("Conexão OK!");

            /*
            var insertCmd = conexao.CreateCommand();

            insertCmd.CommandText = "INSERT INTO Exemplo (Nome, Sobrenome) VALUES( @nome, @sobrenome);";

            var paramNome = new SqlParameter("nome", "Joana");
            var paramSobrenome = new SqlParameter("sobrenome", "Souza");

            insertCmd.Parameters.Add(paramNome);
            insertCmd.Parameters.Add(paramSobrenome);

            insertCmd.ExecuteNonQuery();
            */
            var selectCmd = conexao.CreateCommand();
            selectCmd.CommandText = "select * from Exemplo";

            var resultado = selectCmd.ExecuteReader();

            while (resultado.Read())
            {
                Console.WriteLine($"{resultado["Id"]} - {resultado["Nome"]} {resultado["Sobrenome"]}");
            }

            conexao.Close();
            Console.WriteLine("Conexão Fechada!");
        }
    }
}

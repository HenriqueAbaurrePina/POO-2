﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgendaTelefonica
{
    public partial class Form1 : Form
    {
        List<Contato> list = new List<Contato> ();
        Contato selecionado;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(list,dgvAgenda,this);
            form2.Show();
        }

        private void btnDeletar_Click(object sender, EventArgs e)
        {
            list.Remove(selecionado);
            dgvAgenda.DataSource = null;
            dgvAgenda.DataSource = list;
        }

        private void dgvAgenda_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            selecionado = list[e.RowIndex];
        }

        private void dgvAgenda_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Form3 form3 = new Form3(selecionado, dgvAgenda, this);
            form3.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgendaTelefonica
{
    public partial class Form1 : Form
    {
        List<Contato> list = new List<Contato> ();
        Contato selecionado;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(txtNome.Text) ||
               string.IsNullOrWhiteSpace(txtSobrenome.Text) ||
               string.IsNullOrWhiteSpace(txtDDD.Text) ||
               string.IsNullOrWhiteSpace(txtTelefone.Text))
            {
                MessageBox.Show("Dados Incompletos");
            }
            else
            {
                list.Add(new Contato(txtNome.Text, txtSobrenome.Text, txtDDD.Text, txtTelefone.Text));
                
                dgvAgenda.DataSource = null;
                dgvAgenda.DataSource = list;
                
                txtNome.Clear();
                txtSobrenome.Clear();
                txtDDD.Clear();
                txtTelefone.Clear();
            }
        }

        private void btnDeletar_Click(object sender, EventArgs e)
        {
            list.Remove(selecionado);
            dgvAgenda.DataSource = null;
            dgvAgenda.DataSource = list;
        }

        private void dgvAgenda_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            selecionado = list[e.RowIndex];
        }

        private void dgvAgenda_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            MessageBox.Show("Foi editado com sucesso");
        }
    }
}

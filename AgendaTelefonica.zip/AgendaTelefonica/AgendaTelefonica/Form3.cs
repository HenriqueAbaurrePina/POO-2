﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgendaTelefonica
{
    public partial class Form3 : Form
    {
        Contato list;
        Form1 form1;
        DataGridView dgvAgenda;


        public Form3(Contato list, DataGridView dgvAgenda, Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;
            this.dgvAgenda = dgvAgenda;
            this.list = list;
            txtNome.Text = list.nome;
            txtSobrenome.Text = list.sobrenome;
            txtDDD.Text = list.ddd;
            txtTelefone.Text = list.numero;
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            list.nome = txtNome.Text;
            list.sobrenome = txtSobrenome.Text;
            list.ddd = txtDDD.Text;
            list.numero = txtTelefone.Text;
            this.Close();
        }
    }
}

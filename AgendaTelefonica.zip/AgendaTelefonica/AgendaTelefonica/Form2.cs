﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AgendaTelefonica
{
    public partial class Form2 : Form
    {
        List<Contato> list;
        DataGridView dgvAgenda;
        Form1 form1;
        public Form2(List<Contato> list, DataGridView dgvAgenda, Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;
            this.dgvAgenda = dgvAgenda;
            this.list = list;
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text) ||
               string.IsNullOrWhiteSpace(txtSobrenome.Text) ||
               string.IsNullOrWhiteSpace(txtDDD.Text) ||
               string.IsNullOrWhiteSpace(txtTelefone.Text))
            {
                MessageBox.Show("Dados Incompletos");
            }
            else
            {
                list.Add(new Contato(txtNome.Text, txtSobrenome.Text, txtDDD.Text, txtTelefone.Text));

                dgvAgenda.DataSource = null;
                dgvAgenda.DataSource = list;

                txtNome.Clear();
                txtSobrenome.Clear();
                txtDDD.Clear();
                txtTelefone.Clear();
            }
            this.Close();
        }
    }
}
